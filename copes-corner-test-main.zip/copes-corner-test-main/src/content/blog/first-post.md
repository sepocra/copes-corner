---
title: "Ideas, observations and reflections"
description: first post test
pubDate: 2026-01-25
---

A place to capture the way I see the world
